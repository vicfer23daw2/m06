/**
* @author Víctor Fernández Morenilla, Raül March Vehil
* @version 1.0
*/

//  Esdeveniment 'load' s'activa quan tots els recursos de la pàgina s'han descarregat completament.
window.addEventListener('load', function () {

    // Array d'objectes dels alumnes.
    let alumnes = [
        { nom: 'Albert', cognom: 'López', grup: 1 },
        { nom: 'Víctor', cognom: 'Fernández', grup: 1 },
        { nom: 'Raül', cognom: 'March', grup: 1 },
        { nom: 'Gemma', cognom: 'Grau', grup: 2 },
        { nom: 'Lucia', cognom: 'Martínez', grup: 2 },
        { nom: 'Ainhoa', cognom: 'Castillo', grup: 2 },
        { nom: 'Sara', cognom: 'Santamaría', grup: 3 },
        { nom: 'Antonio', cognom: 'Fernández', grup: 3 },
        { nom: 'Lola', cognom: 'Morenilla', grup: 3 },
        { nom: 'Pablo', cognom: 'Fernández', grup: 4 },
        { nom: 'Enric', cognom: 'López', grup: 4 },
        { nom: 'Arnau', cognom: 'Perramon', grup: 4 },
        { nom: 'Adrià', cognom: 'Garcia', grup: 5 },
        { nom: 'Pol', cognom: 'Zubimendi', grup: 5 },
        { nom: 'Estela', cognom: 'Valentín', grup: 5 },
        { nom: 'Blanca', cognom: 'Suarez', grup: 6 },
        { nom: 'Àngel', cognom: 'López', grup: 6 },
        { nom: 'Olivia', cognom: 'Alcaraz', grup: 6 },
        { nom: 'Leonor', cognom: 'Borbón', grup: 7 },
        { nom: 'Fran', cognom: 'Azpilicueta', grup: 7 },
        { nom: 'Paco', cognom: 'Carmona', grup: 7 },
        { nom: 'Saúl', cognom: 'Sula', grup: 8 },
        { nom: 'Jaume', cognom: 'Usetti', grup: 8 },
        { nom: 'Antonia', cognom: 'Iborra', grup: 8 },
        { nom: 'Mercedes', cognom: 'Alcolea', grup: 9 },
        { nom: 'Diego', cognom: 'Herédia', grup: 9 },
        { nom: 'Isabella', cognom: 'Swan', grup: 9 },
        { nom: 'Alicia', cognom: 'Iriarte', grup: 10 },
        { nom: 'Andoni', cognom: 'Zubizarreta', grup: 10 },
        { nom: 'Carlos', cognom: 'Vargas', grup: 10 },
    ];

    crearTabla();
    gestionarSeleccioGrups();
    gestionarIntercanvis();

    /****************************************************************************************** */
    // Introdueix filas i cel·les a la taula. Introdueix el nom dels alumnes del array a les cel·les.
    function crearTabla() {
        // Ordena l'array per número de grup
        alumnes.sort((a, b) => a.grup - b.grup);

        let taula = document.getElementById("taula-alumnes");
        let celda = taula.getElementsByTagName("td");

        for (let f = 0; f < 5; f++) {
            let fila = taula.insertRow(f);
            for (let c = 0; c < 6; c++) {
                fila.insertCell(c);
            };
        };

        for (let i = 0; i < alumnes.length; i++) {
            let estudiant = alumnes[i].nom;
            celda[i].textContent = estudiant;
        };
    };

    /****************************************************************************************** */
    // Borra la taula
    function borrarTabla() {
        let taula = document.getElementById("taula-alumnes");
        while (taula.firstChild) {
            taula.removeChild(taula.firstChild);
        };
    };

    /****************************************************************************************** */
    // Selecció de grups, aplicació d'estils, mostrar el membres del grup.

    function gestionarSeleccioGrups() {
        let llistaGrups = Array.from(document.getElementById("llista-grups").getElementsByTagName("li"));
        let pupitres = Array.from(document.getElementById("taula-alumnes").getElementsByTagName("td"));
        let llistaIntegrants = document.getElementById("llista-integrants");

        // Esdeveniment 'mouseover' a cada grup de la llista de grups.
        llistaGrups.forEach((grupLlista) => {
            grupLlista.addEventListener("mouseover", function () {
                // Obté el número de grup del atribut "value"
                let grupValue = parseInt(grupLlista.getAttribute("value"));
                // Treu l'estil a tots els grups de la llista
                llistaGrups.forEach(grupo => grupo.classList.remove("grupo-seleccionado"));
                // Afegeix l'estil al grup de la llista on tens el mouse.
                grupLlista.classList.add("grupo-seleccionado");
                // Treu l'estil a totes les cel·les de la taula
                pupitres.forEach(celda => celda.classList.remove("alumno-seleccionado"));
                // Afegeix l'estil a les cel·les dels alumnes amb el mateix grup 
                alumnes.forEach((alumne, index) => {
                    if (alumne.grup === grupValue) {
                        pupitres[index].classList.add("alumno-seleccionado");
                    }
                });

                // Filtrar els alumnes que pertanyen al grup seleccionat
                let membresGrup = alumnes.filter((alumne) => alumne.grup === grupValue);
                // Buidar el contingut actual de llista-integrants
                llistaIntegrants.innerHTML = "";
                // Eliminar l'estil de llista-integrants
                llistaIntegrants.classList.remove("rotacion-horizontal");

                // Iterar pels membres del grup seleccionat i afegir a la llista els noms.
                membresGrup.forEach((membre) => {
                    let elementLlista = document.createElement("li");
                    elementLlista.textContent = `${membre.nom} ${membre.cognom}`;
                    llistaIntegrants.appendChild(elementLlista);
                });

                // Després de 100 milisegons afegeix l'estil (per donar temps a l'actualització de membres).
                setTimeout(() => {
                    llistaIntegrants.classList.add("rotacion-horizontal");
                }, 100);
            });
        });
    };

    /******************************************************************************************/
    // Canvi de pertinença d'alumnes entre grups.
    function gestionarIntercanvis() {
        // Treure estils a tots els grups de llista-grups
        let llistaGrups = Array.from(document.getElementById("llista-grups").getElementsByTagName("li"));
        llistaGrups.forEach(grupLlista => grupLlista.classList.remove("grupo-seleccionado"));

        // Eliminar contingut de llista-integrants
        let llistaIntegrants = document.getElementById("llista-integrants");
        llistaIntegrants.innerHTML = "";

        let grupoSeleccionado = null;
        let pupitres = Array.from(document.getElementById("taula-alumnes").getElementsByTagName("td"));

        // Esdeveniment 'click' a cada cel·la de la taula.
        pupitres.forEach((celda, index) => {
            celda.addEventListener("click", function () {
                // Obtenir el grup al qual pertany l'alumne de la cel·la clicada
                let grupoCeldaSeleccionada = alumnes[index].grup;

                // Si cap grup ha estat seleccionat prèviament
                if (grupoSeleccionado === null) {
                    grupoSeleccionado = grupoCeldaSeleccionada;
                    // Aplica estil a les cel·les del grup seleccionat i el treu a la resta
                    pupitres.forEach((celda, idx) => {
                        if (alumnes[idx].grup === grupoCeldaSeleccionada) {
                            celda.classList.add("alumno-seleccionado2");
                        } else {
                            celda.classList.remove("alumno-seleccionado2");
                        }
                    });
                } else { // Si hi ha un grup seleccionat i es fa clic a una altra cel·la
                    let grupoSegundoClic = grupoCeldaSeleccionada;

                    if (grupoSeleccionado !== grupoSegundoClic) {
                        // Filtrar els alumnes del grup 1 i grup 2
                        let alumnosGrupo1 = alumnes.filter(alumne => alumne.grup === grupoSeleccionado);
                        let alumnosGrupo2 = alumnes.filter(alumne => alumne.grup === grupoSegundoClic);
                        // Canviar la pertinença dels alumnes als grups contraris
                        alumnosGrupo1.forEach(alumne => alumne.grup = grupoSegundoClic);
                        alumnosGrupo2.forEach(alumne => alumne.grup = grupoSeleccionado);
                        // Reestablir a null per tornar a seleccionar
                        grupoSeleccionado = null;
                        // Actualitzar la taula, els intercanvis i la selecció dels grups
                        borrarTabla();
                        crearTabla();
                        gestionarIntercanvis();
                        gestionarSeleccioGrups();
                    };
                };
            });
        });
    };
});